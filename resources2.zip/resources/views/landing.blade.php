@extends('layouts.app')
@section('content')
    @include('partials.hero')
    @include('partials.clients')
    @include('partials.services')
    @include('partials.cta')
    @include('partials.footer')
@endsection
